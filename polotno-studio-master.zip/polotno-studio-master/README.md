# Polotno Studio

**[Launch the application](https://studio.polotno.com/)**

Design Editor made with [Polotno SDK](https://polotno.com/). It several customizations from the default SDK, such as new side panels and saving feature.

### Found a bug? Or want to suggest a feature?

Just create an issues in this repository!
